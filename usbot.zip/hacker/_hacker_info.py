async def hacker_info_f(app, msg):
    await msg.edit("""  Скоро...
    
Made by: @vapgsv
Tester: @real_azart
Version: 2.11 (04.02.23)""", parse_mode="html")
